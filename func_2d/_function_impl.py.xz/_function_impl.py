# 在function_12的基础上
# 生成prompt的方式改为逐个点生成
import os
import logging
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm
from func_2d.utils_memory import *
import cfg
from conf import settings
from func_2d.utils import *
from PIL import Image
# from sam2_train.modeling.sam2_utils import SelectFeat
# from func_2d.PPO_prompt import process_ppo_action
from func_2d.utils_reinfor import *
# 导入特征提取模块
# from func_2d.feature_extraction import extract_target_background_features

args = cfg.parse_args()

# 配置日志记录
def setup_logging():
    log_dir = os.path.join(args.save_path, 'logs')
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, 'train_debug.log')  # 单文件存储
    
    # 创建logger
    logger = logging.getLogger('train_debug')
    logger.setLevel(logging.DEBUG)
    
    # 清除现有的handler，避免重复
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # 文件handler
    file_handler = logging.FileHandler(log_file, mode='a', encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    
    # 控制台handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    
    # 格式化器
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s'
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger

# 初始化logger
logger = setup_logging()

GPUdevice = torch.device('cuda', args.gpu_device)
pos_weight = torch.ones([1]).cuda(device=GPUdevice)*args.loss_pos
# criterion_G = torch.nn.BCEWithLogitsLoss(pos_weight=pos_weight)
criterion_G = WeaklySupervisedSegmentationLoss(args,pos_weight=pos_weight)
mask_type = torch.float32
gap=torch.nn.AdaptiveAvgPool2d([1,1])
torch.backends.cudnn.benchmark = True

# 特征提取功能已移至 func_2d/feature_extraction.py
# 如需使用，请导入: from func_2d.feature_extraction import extract_target_background_features

def random_shift(y, x, scale):
    """在 scale*scale 范围内随机选择一个点"""
    shift_y = torch.randint(0, scale, (y.shape[0],), device=y.device)
    shift_x = torch.randint(0, scale, (x.shape[0],), device=x.device)
    return y * scale + shift_y, x * scale + shift_x


def extract_annotation_points_from_weak_label(weak_label, image_size):
    """
    从弱标签中提取标注点坐标（纯 GPU 版本，无 CPU 传输）
    
    Args:
        weak_label: [H, W] 或 [1, H, W] tensor，1表示目标区域，0.5附近表示背景区域
        image_size: 原始图像尺寸
        
    Returns:
        pos_annotations: [N, 2] tensor，正样本标注点坐标 [x, y]
        neg_annotations: [M, 2] tensor，负样本标注点坐标 [x, y]
    """
    if len(weak_label.shape) == 3:
        weak_label = weak_label.squeeze(0)
    
    H, W = weak_label.shape
    
    pos_mask = weak_label > 0.9
    neg_mask = (weak_label > 0.3) & (weak_label < 0.7)
    
    pos_indices = pos_mask.nonzero(as_tuple=False)  # [N, 2] (row, col)
    neg_indices = neg_mask.nonzero(as_tuple=False)
    
    scale_factor = image_size / max(H, W)
    
    if pos_indices.shape[0] > 0:
        pos_annotations = pos_indices.float().flip(1) * scale_factor  # [N, 2] (x, y)
    else:
        pos_annotations = None
    
    if neg_indices.shape[0] > 0:
        neg_annotations = neg_indices.float().flip(1) * scale_factor
    else:
        neg_annotations = None
    
    return pos_annotations, neg_annotations


def compute_batch_prompt_distance_rewards(coords_batch, labels_batch, masks_weak, image_size, weight=0.1):
    """
    批量计算 Prompt 到弱标签标注点的距离 reward（每个 batch 只提取一次标注点）
    
    Args:
        coords_batch: [B, N, 2] tensor，Prompt 坐标 [x, y]
        labels_batch: [B, N] tensor，Prompt 标签 (1=正, 0=负)
        masks_weak: [B, 1, H, W] tensor，弱标签
        image_size: int，原始图像尺寸
        weight: float，距离 reward 的权重
    
    Returns:
        rewards: [B, N] tensor，距离 reward
    """
    B, N, _ = coords_batch.shape
    rewards = torch.zeros(B, N, device=coords_batch.device)
    
    for b in range(B):
        pos_ann, neg_ann = extract_annotation_points_from_weak_label(masks_weak[b], image_size)
        
        for n in range(N):
            label = int(labels_batch[b, n].item())
            prompt_coord = coords_batch[b, n]  # [2]
            
            annotations = pos_ann if label == 1 else neg_ann
            if annotations is not None and annotations.shape[0] > 0:
                distances = torch.norm(annotations - prompt_coord.unsqueeze(0), dim=1)
                min_dist = distances.min()
                normalized_dist = min_dist / image_size
                rewards[b, n] = -normalized_dist * weight
    
    return rewards


def compute_prompt_distance_reward(prompt_coord, head_type, weak_label, image_size, weight=0.1):
    """
    计算 Prompt 到弱标签标注点的距离 reward
    
    Args:
        prompt_coord: [2] tensor，Prompt 坐标 [x, y]
        head_type: int，1表示正样本，0表示负样本
        weak_label: [H, W] tensor，弱标签
        image_size: int，原始图像尺寸
        weight: float，距离 reward 的权重
        
    Returns:
        dist_reward: float，距离 reward（距离越小，奖励越大）
    """
    pos_annotations, neg_annotations = extract_annotation_points_from_weak_label(weak_label, image_size)
    
    min_dist = None
    
    if head_type == 1 and pos_annotations is not None:
        prompt_tensor = prompt_coord.unsqueeze(0)
        distances = torch.norm(pos_annotations - prompt_tensor, dim=1)
        min_dist = distances.min()
    elif head_type == 0 and neg_annotations is not None:
        prompt_tensor = prompt_coord.unsqueeze(0)
        distances = torch.norm(neg_annotations - prompt_tensor, dim=1)
        min_dist = distances.min()
    
    if min_dist is not None:
        normalized_dist = min_dist / image_size
        dist_reward = -normalized_dist * weight
        return dist_reward.item()
    else:
        return 0.0

def sample_prompts_from_scribble(masks_weak, pos_num, neg_num, image_size):
    """
    从 Scribble 弱标签中随机采样 Prompt 坐标（向量化版本，无 Python for 循环）
    
    Args:
        masks_weak: [B, 1, H, W] 弱标签（Scribble），值为0或1
        pos_num: 正样本数量
        neg_num: 负样本数量
        image_size: 图像尺寸
    
    Returns:
        coords: [B, pos_num+neg_num, 2] 坐标 (x, y)
        labels: [B, pos_num+neg_num] 标签 (1=前景, 0=背景)
    """
    B = masks_weak.shape[0]
    total_num = pos_num + neg_num
    device = masks_weak.device

    fg_mask = masks_weak > 0.5  # [B, 1, H, W]
    bg_mask = ~fg_mask

    fg_flat = fg_mask.flatten(2)  # [B, 1, H*W]
    bg_flat = bg_mask.flatten(2)

    fg_counts = fg_flat.sum(dim=2, keepdim=True)  # [B, 1, 1]
    bg_counts = bg_flat.sum(dim=2, keepdim=True)

    fg_probs = fg_flat.float() / fg_counts.float().clamp(min=1)  # [B, 1, H*W]
    bg_probs = bg_flat.float() / bg_counts.float().clamp(min=1)

    fg_has_pixels = (fg_counts.squeeze(-1) > 0)  # [B, 1]
    bg_has_pixels = (bg_counts.squeeze(-1) > 0)

    coords = torch.zeros(B, total_num, 2, device=device)
    labels = torch.zeros(B, total_num, device=device)

    # 正样本采样
    fg_probs_safe = fg_probs.squeeze(1).clone()  # [B, H*W]
    no_fg_mask = ~fg_has_pixels.squeeze(1)  # [B]
    if no_fg_mask.any():
        fg_probs_safe[no_fg_mask] = 1.0 / fg_probs_safe.shape[1]
    fg_indices = torch.multinomial(fg_probs_safe, pos_num, replacement=True)  # [B, pos_num]
    H = masks_weak.shape[2]
    W = masks_weak.shape[3]
    fg_rows = fg_indices // W  # [B, pos_num]
    fg_cols = fg_indices % W
    coords[:, :pos_num, 0] = fg_cols.float()
    coords[:, :pos_num, 1] = fg_rows.float()
    labels[:, :pos_num] = 1.0

    if no_fg_mask.any():
        rand_x = torch.randint(0, W, (no_fg_mask.sum(), pos_num), device=device).float()
        rand_y = torch.randint(0, H, (no_fg_mask.sum(), pos_num), device=device).float()
        coords[no_fg_mask, :pos_num, 0] = rand_x
        coords[no_fg_mask, :pos_num, 1] = rand_y

    # 负样本采样
    bg_probs_safe = bg_probs.squeeze(1).clone()  # [B, H*W]
    no_bg_mask = ~bg_has_pixels.squeeze(1)  # [B]
    if no_bg_mask.any():
        bg_probs_safe[no_bg_mask] = 1.0 / bg_probs_safe.shape[1]
    bg_indices = torch.multinomial(bg_probs_safe, neg_num, replacement=True)  # [B, neg_num]
    bg_rows = bg_indices // W
    bg_cols = bg_indices % W
    coords[:, pos_num:, 0] = bg_cols.float()
    coords[:, pos_num:, 1] = bg_rows.float()
    labels[:, pos_num:] = 0.0

    if no_bg_mask.any():
        rand_x = torch.randint(0, W, (no_bg_mask.sum(), neg_num), device=device).float()
        rand_y = torch.randint(0, H, (no_bg_mask.sum(), neg_num), device=device).float()
        coords[no_bg_mask, pos_num:, 0] = rand_x
        coords[no_bg_mask, pos_num:, 1] = rand_y

    return coords, labels


def _sam_forward_with_prompts(net, feats, batch_prompts, batch_labels, GPUdevice, B, mask_input=None):
    prompt_tensors = torch.stack([torch.tensor(batch_prompts[b], device=GPUdevice) for b in range(B)], dim=0)
    label_tensors = torch.stack([torch.tensor([l[0] for l in batch_labels[b]], device=GPUdevice) for b in range(B)], dim=0)
    
    if prompt_tensors.shape[1] > 0:
        points = [prompt_tensors.float(), label_tensors.float()]
    else:
        points = None
    
    with torch.no_grad():
        se, de = net.sam_prompt_encoder(
            points=points,
            boxes=None,
            masks=mask_input,
            batch_size=B
        )
    
    low_res_multimasks, iou_prediction, sam_output_tokens, object_score_logits = net.sam_mask_decoder(
        image_embeddings=feats[-1],
        image_pe=net.sam_prompt_encoder.get_dense_pe(),
        sparse_prompt_embeddings=se,
        dense_prompt_embeddings=de,
        multimask_output=False,
        repeat_image=False,
        high_res_features=feats[:-1]
    )
    
    return low_res_multimasks, iou_prediction, object_score_logits


def _run_memory_attention(net, original_vision_feats, vision_pos_embeds, memory_bank_list, args, B, feat_sizes, use_memory_attention):
    vision_feats = [feat.clone() for feat in original_vision_feats]
    vision_pos_embeds_copy = [pos.clone() for pos in vision_pos_embeds]
    
    if len(memory_bank_list) == 0:
        vision_feats[-1] = vision_feats[-1] + torch.zeros(1, B, net.hidden_dim, device="cuda")
        vision_pos_embeds_copy[-1] = vision_pos_embeds_copy[-1] + torch.zeros(1, B, net.hidden_dim, device="cuda")
    else:
        memory_feats_list = [element[0].cuda(non_blocking=True).flatten(2).permute(2, 0, 1) for element in memory_bank_list]
        memory_pos_list = [element[1].cuda(non_blocking=True).flatten(2).permute(2, 0, 1) for element in memory_bank_list]
        image_embed_list = [element[3].cuda(non_blocking=True) for element in memory_bank_list]

        memory_stack_ori = torch.stack(memory_feats_list, dim=0)
        memory_pos_stack_ori = torch.stack(memory_pos_list, dim=0)
        image_embed_stack_ori = torch.stack(image_embed_list, dim=0)

        vision_feats_temp = vision_feats[-1].permute(1, 0, 2).reshape(B, -1, 64, 64)
        vision_feats_temp = vision_feats_temp.reshape(B, -1)

        image_embed_stack_ori = F.normalize(image_embed_stack_ori, p=2, dim=1)
        vision_feats_temp = F.normalize(vision_feats_temp, p=2, dim=1)

        similarity_scores = torch.mm(image_embed_stack_ori, vision_feats_temp.t()).t()
        similarity_scores = F.softmax(similarity_scores, dim=1)

        sampled_indices = torch.multinomial(similarity_scores, num_samples=args.num_memory_used, replacement=True).squeeze(1)

        memory_stack_ori_new = (memory_stack_ori[sampled_indices].squeeze(3).permute(1, 2, 0, 3))
        memory = memory_stack_ori_new.reshape(-1, memory_stack_ori_new.size(2), memory_stack_ori_new.size(3))

        memory_pos_stack_new = (memory_pos_stack_ori[sampled_indices].squeeze(3).permute(1, 2, 0, 3))
        memory_pos = memory_pos_stack_new.reshape(-1, memory_stack_ori_new.size(2), memory_stack_ori_new.size(3))

        vision_feats[-1] = net.memory_attention(
            curr=[vision_feats[-1]],
            curr_pos=[vision_pos_embeds_copy[-1]],
            memory=memory,
            memory_pos=memory_pos,
            num_obj_ptr_tokens=0
        )

    if use_memory_attention:
        feats = [feat.permute(1, 2, 0).view(B, -1, *feat_size) 
                for feat, feat_size in zip(vision_feats[::-1], feat_sizes[::-1])][::-1]
    else:
        feats = [feat.permute(1, 2, 0).view(B, -1, *feat_size) 
                for feat, feat_size in zip(original_vision_feats[::-1], feat_sizes[::-1])][::-1]
    
    return feats


def train_sam(args, net: nn.Module, optimizer, train_loader, epoch,kmeans_target,kmeans_background,memory_bank_list,scaler=None,ppo_agent=None):
    # ppo_agent现在总是必需的，不再检查None
    
    # 判断是否处于 Prompt Warmup 阶段
    use_prompt_warmup = getattr(args, 'use_prompt_warmup', False)
    prompt_warmup_epochs = getattr(args, 'prompt_warmup_epochs', 10)
    in_warmup = use_prompt_warmup and (epoch < prompt_warmup_epochs)
    if in_warmup:
        logger.info(f"=== Prompt Warmup 阶段 (epoch {epoch}/{prompt_warmup_epochs-1})：SAM梯度回传使用Scribble采样Prompt ===")
    
    per_step_bp = getattr(args, 'per_step_backprop', False)
    if per_step_bp and not in_warmup:
        logger.info(f"=== 策略B：每步回传模式 (per_step_backprop=True) ===")
    elif per_step_bp and in_warmup:
        logger.info(f"=== 策略B+Warmup：PPO循环no_grad，Scribble Prompt逐步回传 ===")
    
    # 记录epoch开始信息
    logger.info(f"=== 开始训练第 {epoch} 个epoch ===")
    
    cluster_trained = False

    
    # train mode
    net.train()
    if optimizer is not None:
        optimizer.zero_grad()

    # init
    epoch_loss = 0
    n_finite_loss = 0  # 仅对有限 loss 做平均，避免 nan 污染
    
    # 收集 PPO 指标
    all_ppo_losses = []
    all_dist_entropies = []

    
    lossfunc = criterion_G
    feat_sizes = [(256, 256), (128, 128), (64, 64)]

    train_data_target = []
    train_data_background = []
    prompt_counts = []  # 新增：用于统计每张图生成的prompt数量
    with tqdm(total=len(train_loader), desc=f'Epoch {epoch}', unit='img') as pbar:
        for ind, pack in enumerate(train_loader):
            with torch.autocast(device_type='cuda', dtype=torch.bfloat16):
                # to_cat_feat_background = []
                # to_cat_feat_target_used = []
                # to_cat_feat_background_used = []

                # input image and gt masks
                imgs = pack['image'].to(dtype = mask_type, device = GPUdevice)
                masks = pack['mask'].to(dtype = mask_type, device = GPUdevice)
                masks_weak = pack['mask_weak'].to(dtype = mask_type, device = GPUdevice)
                name = pack['image_meta_dict']['filename_or_obj']


                # click prompt: unsqueeze to indicate only one click, add more click across this dimension
                if 'pt' in pack:
                    pt_temp = pack['pt'].to(device = GPUdevice)
                    pt = pt_temp.unsqueeze(1)
                    point_labels_temp = pack['p_label'].to(device = GPUdevice)
                    point_labels = point_labels_temp.unsqueeze(1)
                    coords_torch = torch.as_tensor(pt, dtype=torch.float, device=GPUdevice)
                    labels_torch = torch.as_tensor(point_labels, dtype=torch.int, device=GPUdevice)
                else:
                    coords_torch = None
                    labels_torch = None

                '''Train image encoder'''

                backbone_out = net.forward_image(imgs)

                # backbone_out: 
                # vision_feats : [b,256,64,64] (backbone_fpn[-1])
                # vision_pos_enc : [b,256,256,256] [b,256,128,128] [b,256,64,64]
                # backbone_fpn : [b,256,256,256] [b,256,128,128] [b,256,64,64]
                
                _, vision_feats, vision_pos_embeds, _ = net._prepare_backbone_features(backbone_out)
                del backbone_out

                # Image Encoder 已冻结(requires_grad=False)，detach其输出以节省计算图内存
                # 梯度只需流过 Memory Attention 和 Mask Decoder
                vision_feats = [feat.detach() for feat in vision_feats]
                vision_pos_embeds = [pos.detach() for pos in vision_pos_embeds]

                original_vision_feats = [feat.clone() for feat in vision_feats]

                '''Train memory attention to condition on meomory bank'''
                B = vision_feats[-1].size(1)  # batch size
                use_memory_attention = getattr(args, 'use_memory_attention', True)
                
                feats = _run_memory_attention(net, original_vision_feats, vision_pos_embeds, memory_bank_list, args, B, feat_sizes, use_memory_attention)
                
                B = feats[-1].shape[0]
                all_coords = []
                all_labels = []
                
                # 为整个batch初始化prompts和labels（每个样本一个列表）
                batch_prompts = [[] for _ in range(B)]  # List[List[[x,y]]]
                batch_labels = [[] for _ in range(B)]   # List[List[label]]
                
                # 初始化当前mask为全0（整个batch）
                current_mask = torch.zeros(B, 1, args.image_size, args.image_size, device=GPUdevice)
                current_mask_logits = torch.zeros(B, 1, args.image_size, args.image_size, device=GPUdevice)
                current_mask_logits_low_res = torch.zeros(B, 1, 256, 256, device=GPUdevice)
                # 计算每个样本的初始loss
                current_losses = [lossfunc(current_mask[b:b+1], masks_weak[b:b+1]).item() for b in range(B)]
                
                # 固定生成Prompt数量：先生成正样本，再生成负样本
                target_prompt_num = args.positive_prompt_num  # 正样本数量
                background_prompt_num = args.negative_prompt_num  # 负样本数量
                
                # 预计算标注点缓存（每个batch只提取一次，避免重复调用）
                use_prompt_dist_reward = getattr(args, 'use_prompt_dist_reward', False)
                batch_pos_annotations = [None] * B
                batch_neg_annotations = [None] * B
                if use_prompt_dist_reward:
                    for b in range(B):
                        batch_pos_annotations[b], batch_neg_annotations[b] = extract_annotation_points_from_weak_label(masks_weak[b], args.image_size)
                
                # 第一阶段：为整个batch生成正样本prompts
                for i in range(target_prompt_num):
                    # 构建batch state: [B, 259, 64, 64]
                    state = feats[-1]  # [B, 256, 64, 64]
                    mask_resized = F.interpolate(current_mask, size=(state.shape[2], state.shape[3]), mode='bilinear')  # [B, 1, 64, 64]

                    # 为整个batch一次性构建prompt_map
                    prompt_map = encode_prompts_to_map_gpu(
                        batch_prompts,  # List[List[[x,y]]]
                        [[l[0] for l in batch_labels[b]] for b in range(B)],  # List[List[label]]
                        state.shape[2],
                        state.shape[3],
                        sigma=1.0,
                        device=state.device,
                        batch_size=B
                    )  # [B, 2, H, W]

                    current_state = torch.cat([state, mask_resized, prompt_map], dim=1)  # [B, 259, 64, 64]
                    
                    # 为整个batch同时生成action（PPO agent已经支持batch）
                    action_coords_batch = ppo_agent.select_action_pos(current_state, deterministic=False)  # [B, 2] numpy array
                    
                    # 为每个样本处理action和reward（因为每张图像的prompts不同，SAM推理需要单独处理）
                    batch_new_masks = []
                    current_action_coords = []
                        
                    for b in range(B):
                        y = action_coords_batch[b, 0]
                        x = action_coords_batch[b, 1]
                        label = 1  # 正样本
                        
                        batch_prompts[b].append([x, y])
                        batch_labels[b].append([label])
                        current_action_coords.append((x, y))
                    
                    # Batch处理：为整个batch同时进行SAM推理（因为prompt数量相同）
                    per_step_bp = getattr(args, 'per_step_backprop', False) and not in_warmup
                    
                    if per_step_bp:
                        mask_input_batch = None if i == 0 else current_mask_logits_low_res.detach()
                        low_res_multimasks_batch, iou_pred_batch, _ = _sam_forward_with_prompts(
                            net, feats, batch_prompts, batch_labels, GPUdevice, B,
                            mask_input=mask_input_batch
                        )
                    else:
                        with torch.no_grad():
                            mask_input_batch = None if i == 0 else current_mask_logits_low_res
                            low_res_multimasks_batch, _, _ = _sam_forward_with_prompts(
                                net, feats, batch_prompts, batch_labels, GPUdevice, B,
                                mask_input=mask_input_batch
                            )
                    
                    new_masks_logits_low_res_batch = low_res_multimasks_batch
                    new_masks_logits_batch = F.interpolate(low_res_multimasks_batch, 
                                                    size=(args.image_size, args.image_size),
                                                    mode="bilinear", 
                                                    align_corners=False)
                    new_masks_batch = (F.sigmoid(new_masks_logits_batch)).float()
                    current_mask_logits = new_masks_logits_batch.detach() if per_step_bp else new_masks_logits_batch
                    current_mask_logits_low_res = new_masks_logits_low_res_batch.detach() if per_step_bp else new_masks_logits_low_res_batch
                    
                    for b in range(B):
                        new_loss_b = lossfunc(new_masks_batch[b:b+1], masks_weak[b:b+1]).item()
                        x, y = current_action_coords[b]

                        improvement_reward_weight = getattr(args, 'improvement_reward_weight', 1.0)
                        loss_improvement = current_losses[b] - new_loss_b
                        improvement_reward = loss_improvement * improvement_reward_weight
                        reward = improvement_reward

                        if use_prompt_dist_reward:
                            prompt_dist_reward_weight = getattr(args, 'prompt_dist_reward_weight', 0.1)
                            prompt_coord = torch.tensor([x, y], device=masks_weak.device, dtype=torch.float32)
                            annotations = batch_pos_annotations[b]
                            if annotations is not None and annotations.shape[0] > 0:
                                distances = torch.norm(annotations - prompt_coord.unsqueeze(0), dim=1)
                                min_dist = distances.min()
                                reward += (-min_dist / args.image_size * prompt_dist_reward_weight).item()

                        current_losses[b] = new_loss_b
                        ppo_agent.buffer.rewards.append(reward)
                        ppo_agent.buffer.is_terminals.append(False)

                    if per_step_bp:
                        step_loss = lossfunc(F.interpolate(low_res_multimasks_batch, size=(args.out_size, args.out_size)), masks_weak)
                        if args.use_entropy_constraint and args.entropy_constraint_weight > 0:
                            pred_probs = torch.sigmoid(F.interpolate(low_res_multimasks_batch, size=(args.out_size, args.out_size)))
                            eps = 1e-7
                            pred_probs = torch.clamp(pred_probs, min=eps, max=1.0 - eps)
                            entropy = -pred_probs * torch.log(pred_probs) - (1 - pred_probs) * torch.log(1 - pred_probs)
                            entropy_loss = entropy.mean()
                            if torch.isfinite(entropy_loss):
                                step_loss = step_loss + args.entropy_constraint_weight * entropy_loss
                        
                        if torch.isfinite(step_loss):
                            if scaler is None:
                                step_loss.backward()
                                optimizer.step()
                                optimizer.zero_grad()
                            else:
                                scaler.scale(step_loss).backward()
                                scaler.step(optimizer)
                                scaler.update()
                                optimizer.zero_grad()
                            epoch_loss += step_loss.item()
                            n_finite_loss += 1
                    
                    current_mask = new_masks_batch.detach() if per_step_bp else new_masks_batch
                    
                    if per_step_bp and use_memory_attention:
                        feats = _run_memory_attention(net, original_vision_feats, vision_pos_embeds, memory_bank_list, args, B, feat_sizes, use_memory_attention)
                
                # 第二阶段：为整个batch生成负样本prompts（类似正样本的处理）
                for i in range(background_prompt_num):
                    # 构建batch state
                    state = feats[-1]
                    mask_resized = F.interpolate(current_mask, size=(state.shape[2], state.shape[3]), mode='bilinear')

                    # 为整个batch一次性构建prompt_map
                    prompt_map = encode_prompts_to_map_gpu(
                        batch_prompts,  # List[List[[x,y]]]
                        [[l[0] for l in batch_labels[b]] for b in range(B)],  # List[List[label]]
                        state.shape[2],
                        state.shape[3],
                        sigma=1.0,
                        device=state.device,
                        batch_size=B
                    )  # [B, 2, H, W]

                    current_state = torch.cat([state, mask_resized, prompt_map], dim=1)  # [B, 259, 64, 64]
                    
                    # 为整个batch同时生成负样本action
                    action_coords_batch = ppo_agent.select_action_neg(current_state, deterministic=False)
                    
                    batch_new_masks = []
                    current_action_coords_neg = []
                    
                    for b in range(B):
                        y = action_coords_batch[b, 0]
                        x = action_coords_batch[b, 1]
                        label = 0  # 负样本
                        reward = 0.0  # 初始化reward
                        
                        batch_prompts[b].append([x, y])
                        batch_labels[b].append([label])
                        current_action_coords_neg.append((x, y))
                    
                    # Batch处理：为整个batch同时进行SAM推理（因为prompt数量相同）
                    per_step_bp = getattr(args, 'per_step_backprop', False) and not in_warmup
                    
                    if per_step_bp:
                        low_res_multimasks_batch, iou_pred_batch, _ = _sam_forward_with_prompts(
                            net, feats, batch_prompts, batch_labels, GPUdevice, B,
                            mask_input=current_mask_logits_low_res.detach()
                        )
                    else:
                        with torch.no_grad():
                            low_res_multimasks_batch, _, _ = _sam_forward_with_prompts(
                                net, feats, batch_prompts, batch_labels, GPUdevice, B,
                                mask_input=current_mask_logits_low_res
                            )
                    
                    new_masks_logits_low_res_batch = low_res_multimasks_batch
                    new_masks_logits_batch = F.interpolate(low_res_multimasks_batch, 
                                                size=(args.image_size, args.image_size),
                                                mode="bilinear", 
                                                align_corners=False)
                    new_masks_batch = (F.sigmoid(new_masks_logits_batch)).float()
                    current_mask_logits = new_masks_logits_batch.detach() if per_step_bp else new_masks_logits_batch
                    current_mask_logits_low_res = new_masks_logits_low_res_batch.detach() if per_step_bp else new_masks_logits_low_res_batch
                    
                    for b in range(B):
                        new_loss_b = lossfunc(new_masks_batch[b:b+1], masks_weak[b:b+1]).item()
                        x, y = current_action_coords_neg[b]

                        improvement_reward_weight = getattr(args, 'improvement_reward_weight', 1.0)
                        loss_improvement = current_losses[b] - new_loss_b
                        improvement_reward = loss_improvement * improvement_reward_weight
                        reward = improvement_reward

                        if use_prompt_dist_reward:
                            prompt_dist_reward_weight = getattr(args, 'prompt_dist_reward_weight', 0.1)
                            prompt_coord = torch.tensor([x, y], device=masks_weak.device, dtype=torch.float32)
                            annotations = batch_neg_annotations[b]
                            if annotations is not None and annotations.shape[0] > 0:
                                distances = torch.norm(annotations - prompt_coord.unsqueeze(0), dim=1)
                                min_dist = distances.min()
                                reward += (-min_dist / args.image_size * prompt_dist_reward_weight).item()

                        current_losses[b] = new_loss_b
                        ppo_agent.buffer.rewards.append(reward)
                        is_terminal = (i == background_prompt_num - 1)
                        ppo_agent.buffer.is_terminals.append(is_terminal)

                    if per_step_bp:
                        step_loss = lossfunc(F.interpolate(low_res_multimasks_batch, size=(args.out_size, args.out_size)), masks_weak)
                        if args.use_entropy_constraint and args.entropy_constraint_weight > 0:
                            pred_probs = torch.sigmoid(F.interpolate(low_res_multimasks_batch, size=(args.out_size, args.out_size)))
                            eps = 1e-7
                            pred_probs = torch.clamp(pred_probs, min=eps, max=1.0 - eps)
                            entropy = -pred_probs * torch.log(pred_probs) - (1 - pred_probs) * torch.log(1 - pred_probs)
                            entropy_loss = entropy.mean()
                            if torch.isfinite(entropy_loss):
                                step_loss = step_loss + args.entropy_constraint_weight * entropy_loss
                        
                        if torch.isfinite(step_loss):
                            if scaler is None:
                                step_loss.backward()
                                optimizer.step()
                                optimizer.zero_grad()
                            else:
                                scaler.scale(step_loss).backward()
                                scaler.step(optimizer)
                                scaler.update()
                                optimizer.zero_grad()
                            epoch_loss += step_loss.item()
                            n_finite_loss += 1
                    
                    current_mask = new_masks_batch.detach() if per_step_bp else new_masks_batch
                    
                    if per_step_bp and use_memory_attention:
                        feats = _run_memory_attention(net, original_vision_feats, vision_pos_embeds, memory_bank_list, args, B, feat_sizes, use_memory_attention)
                
                # 统计prompt数量并转换为tensor
                prompt_counts.extend([len(batch_prompts[b]) for b in range(B)])
                
                # 将prompts转换为batch tensor
                max_prompts = max(len(batch_prompts[b]) for b in range(B))
                # 如果prompt数量不同，需要padding
                padded_prompts = []
                padded_labels = []
                for b in range(B):
                    num_prompts = len(batch_prompts[b])
                    if num_prompts < max_prompts:
                        # Padding with zeros
                        pad_prompts = batch_prompts[b] + [[0, 0]] * (max_prompts - num_prompts)
                        pad_labels = batch_labels[b] + [[0]] * (max_prompts - num_prompts)
                    else:
                        pad_prompts = batch_prompts[b]
                        pad_labels = batch_labels[b]
                    padded_prompts.append(torch.tensor(pad_prompts, device=GPUdevice))
                    padded_labels.append(torch.tensor([l[0] for l in pad_labels], device=GPUdevice))
                
                coords_torch = torch.stack(padded_prompts, dim=0)  # [B, N, 2]
                labels_torch = torch.stack(padded_labels, dim=0)  # [B, N]
                
                # 更新 PPO agent 并收集指标
                ppo_metrics = ppo_agent.update()
                if ppo_metrics:
                    if ppo_metrics['ppo_loss'] is not None:
                        all_ppo_losses.append(ppo_metrics['ppo_loss'])
                    if ppo_metrics['dist_entropy'] is not None:
                        all_dist_entropies.append(ppo_metrics['dist_entropy'])

                image_embed = feats[-1]
                high_res_feats = feats[:-1]
                
                per_step_bp = getattr(args, 'per_step_backprop', False)
                
                if per_step_bp and not in_warmup:
                    with torch.no_grad():
                        final_low_res = current_mask_logits_low_res.detach()
                        final_high_res = F.interpolate(final_low_res, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                        maskmem_features, maskmem_pos_enc = net._encode_new_memory(
                            current_vision_feats=vision_feats,
                            feat_sizes=feat_sizes,
                            pred_masks_high_res=final_high_res,
                            is_mask_from_pts=False
                        )
                        maskmem_features = maskmem_features.to(vision_feats[-1].dtype).to(device=GPUdevice, non_blocking=True)
                        maskmem_pos_enc = maskmem_pos_enc[0].to(vision_feats[-1].dtype).to(device=GPUdevice, non_blocking=True)
                        
                        mean_iou = 0
                        ious = []
                        if len(memory_bank_list) > args.memory_bank_size:
                            ious = [element[2] for element in memory_bank_list]
                            ious = torch.stack(ious)
                            mean_iou = ious.mean()
                        for batch_idx in range(maskmem_features.size(0)):
                            mf_batch = maskmem_features[batch_idx].unsqueeze(0)
                            mp_batch = maskmem_pos_enc[batch_idx].unsqueeze(0)
                            ie_batch = image_embed[batch_idx].reshape(-1)
                            memory_bank_list.append([mf_batch.detach(), mp_batch.detach(), torch.tensor(0.5), ie_batch.detach()])
                        if len(memory_bank_list) > args.memory_bank_size:
                            memory_bank_list = update_memory_2(memory_bank_list, args.memory_bank_size)
                elif per_step_bp and in_warmup:
                    fg_mask = masks_weak > 0.5
                    bg_mask = ~fg_mask
                    fg_counts = fg_mask.flatten(2).sum(dim=2).squeeze(1)
                    bg_counts = bg_mask.flatten(2).sum(dim=2).squeeze(1)
                    no_fg = fg_counts == 0
                    no_bg = bg_counts == 0
                    if no_fg.any() or no_bg.any():
                        for b in range(masks_weak.shape[0]):
                            fname = name[b] if b < len(name) else f'batch_idx_{b}'
                            if no_fg[b]:
                                logging.warning(f'图像无前景像素: {fname}')
                            if no_bg[b]:
                                logging.warning(f'图像无背景像素: {fname}')
                    warmup_coords, warmup_labels = sample_prompts_from_scribble(
                        masks_weak, args.positive_prompt_num, args.negative_prompt_num, args.image_size
                    )
                    
                    total_prompts = warmup_coords.shape[1]
                    warmup_mask_logits_low_res = None
                    
                    for step_i in range(total_prompts):
                        step_coords = warmup_coords[:, step_i:step_i+1, :]
                        step_labels = warmup_labels[:, step_i:step_i+1]
                        
                        with torch.no_grad():
                            if step_coords is not None and step_coords.shape[1] > 0:
                                points = [step_coords.float(), step_labels.float()]
                            else:
                                points = None
                            se, de = net.sam_prompt_encoder(
                                points=points,
                                boxes=None,
                                masks=warmup_mask_logits_low_res.detach() if warmup_mask_logits_low_res is not None else None,
                                batch_size=B
                            )
                        
                        low_res_multimasks, iou_prediction, _, _ = net.sam_mask_decoder(
                            image_embeddings=feats[-1],
                            image_pe=net.sam_prompt_encoder.get_dense_pe(),
                            sparse_prompt_embeddings=se,
                            dense_prompt_embeddings=de,
                            multimask_output=False,
                            repeat_image=False,
                            high_res_features=feats[:-1]
                        )
                        
                        warmup_mask_logits_low_res = low_res_multimasks.detach()
                        
                        step_loss = lossfunc(F.interpolate(low_res_multimasks, size=(args.out_size, args.out_size)), masks_weak)
                        if args.use_entropy_constraint and args.entropy_constraint_weight > 0:
                            pred_probs = torch.sigmoid(F.interpolate(low_res_multimasks, size=(args.out_size, args.out_size)))
                            eps = 1e-7
                            pred_probs = torch.clamp(pred_probs, min=eps, max=1.0 - eps)
                            entropy = -pred_probs * torch.log(pred_probs) - (1 - pred_probs) * torch.log(1 - pred_probs)
                            entropy_loss = entropy.mean()
                            if torch.isfinite(entropy_loss):
                                step_loss = step_loss + args.entropy_constraint_weight * entropy_loss
                        
                        if torch.isfinite(step_loss):
                            if scaler is None:
                                step_loss.backward()
                                optimizer.step()
                                optimizer.zero_grad()
                            else:
                                scaler.scale(step_loss).backward()
                                scaler.step(optimizer)
                                scaler.update()
                                optimizer.zero_grad()
                            epoch_loss += step_loss.item()
                            n_finite_loss += 1
                        
                        if use_memory_attention:
                            feats = _run_memory_attention(net, original_vision_feats, vision_pos_embeds, memory_bank_list, args, B, feat_sizes, use_memory_attention)
                    
                    with torch.no_grad():
                        final_high_res = F.interpolate(warmup_mask_logits_low_res, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                        maskmem_features, maskmem_pos_enc = net._encode_new_memory(
                            current_vision_feats=vision_feats,
                            feat_sizes=feat_sizes,
                            pred_masks_high_res=final_high_res,
                            is_mask_from_pts=False
                        )
                        maskmem_features = maskmem_features.to(vision_feats[-1].dtype).to(device=GPUdevice, non_blocking=True)
                        maskmem_pos_enc = maskmem_pos_enc[0].to(vision_feats[-1].dtype).to(device=GPUdevice, non_blocking=True)
                        mean_iou = 0
                        ious = []
                        if len(memory_bank_list) > args.memory_bank_size:
                            ious = [element[2] for element in memory_bank_list]
                            ious = torch.stack(ious)
                            mean_iou = ious.mean()
                        for batch_idx in range(maskmem_features.size(0)):
                            mf_batch = maskmem_features[batch_idx].unsqueeze(0)
                            mp_batch = maskmem_pos_enc[batch_idx].unsqueeze(0)
                            ie_batch = image_embed[batch_idx].reshape(-1)
                            memory_bank_list.append([mf_batch.detach(), mp_batch.detach(), torch.tensor(0.5), ie_batch.detach()])
                        if len(memory_bank_list) > args.memory_bank_size:
                            memory_bank_list = update_memory_2(memory_bank_list, args.memory_bank_size)
                else:
                    '''prompt encoder'''
                    if in_warmup:
                        fg_mask = masks_weak > 0.5
                        bg_mask = ~fg_mask
                        fg_counts = fg_mask.flatten(2).sum(dim=2).squeeze(1)  # [B]
                        bg_counts = bg_mask.flatten(2).sum(dim=2).squeeze(1)  # [B]
                        no_fg = fg_counts == 0
                        no_bg = bg_counts == 0
                        if no_fg.any() or no_bg.any():
                            for b in range(masks_weak.shape[0]):
                                fname = name[b] if b < len(name) else f'batch_idx_{b}'
                                if no_fg[b]:
                                    logging.warning(f'图像无前景像素: {fname}')
                                if no_bg[b]:
                                    logging.warning(f'图像无背景像素: {fname}')
                        warmup_coords, warmup_labels = sample_prompts_from_scribble(
                            masks_weak, args.positive_prompt_num, args.negative_prompt_num, args.image_size
                        )
                        coords_for_sam = warmup_coords
                        labels_for_sam = warmup_labels
                    else:
                        coords_for_sam = coords_torch
                        labels_for_sam = labels_torch
                
                    with torch.no_grad():
                        flag = False
                        if coords_for_sam is not None and coords_for_sam.shape[1]>0:
                            points = [coords_for_sam.float().detach(),labels_for_sam.float().detach()]
                        else: points=None
                    
                        se, de = net.sam_prompt_encoder(
                            points=points,
                            boxes = None,
                            masks = current_mask_logits_low_res,
                            batch_size = feats[-1].shape[0],
                        )
                    
                    '''train mask decoder'''       
                    low_res_multimasks, iou_prediction, sam_output_tokens, object_score_logits = net.sam_mask_decoder(
                            image_embeddings=image_embed,
                            image_pe=net.sam_prompt_encoder.get_dense_pe(), 
                            sparse_prompt_embeddings=se,
                            dense_prompt_embeddings=de, 
                            multimask_output=False,
                            repeat_image=False,
                            high_res_features = high_res_feats
                        )
                
                    pred = F.interpolate(low_res_multimasks,size=(args.out_size,args.out_size))
                    high_res_multimasks = F.interpolate(low_res_multimasks, size=(args.image_size, args.image_size),
                                                        mode="bilinear", align_corners=False)
                    iou_predictions = iou_prediction
                    '''memory encoder'''       
                    maskmem_features, maskmem_pos_enc = net._encode_new_memory(
                        current_vision_feats=vision_feats,
                        feat_sizes=feat_sizes,
                        pred_masks_high_res=high_res_multimasks,
                        is_mask_from_pts=flag)  
                        
                    maskmem_features = maskmem_features.to(vision_feats[-1].dtype)
                    maskmem_features = maskmem_features.to(device=GPUdevice, non_blocking=True)
                    maskmem_pos_enc = maskmem_pos_enc[0].to(vision_feats[-1].dtype)
                    maskmem_pos_enc = maskmem_pos_enc.to(device=GPUdevice, non_blocking=True)
                    mean_iou = 0
                    ious = []
                    if len(memory_bank_list) > args.memory_bank_size:
                        ious=[element[2] for element in memory_bank_list]
                        ious=torch.stack(ious)
                        mean_iou = ious.mean()
                    for batch in range(maskmem_features.size(0)):
                        if iou_predictions[batch, 0]>=mean_iou :
                            mf_batch = maskmem_features[batch].unsqueeze(0)
                            mp_batch = maskmem_pos_enc[batch].unsqueeze(0)
                            ie_batch = image_embed[batch].reshape(-1)
                            memory_bank_list.append([mf_batch.detach(),
                                                        mp_batch.detach(),
                                                        iou_predictions[batch, 0],
                                                        ie_batch.detach(),])
                    if len(memory_bank_list) > args.memory_bank_size:
                        memory_bank_list = update_memory_2(memory_bank_list,args.memory_bank_size)


                    # backpropagation
                    # 弱监督mask

                    # 计算基础loss
                    base_loss = lossfunc(pred, masks_weak)

                    loss = base_loss

                    # 熵约束项：使输出偏向0或1而不是中间值
                    if args.use_entropy_constraint and args.entropy_constraint_weight > 0:
                        # 将logits转换为概率
                        pred_probs = torch.sigmoid(pred)

                        # 数值稳定性：确保概率在 [eps, 1-eps] 范围内
                        eps = 1e-7  # 增大eps以提高数值稳定性
                        pred_probs = torch.clamp(pred_probs, min=eps, max=1.0 - eps)

                        # 再次检查概率值，确保1-p也在有效范围内
                        pred_probs_1 = 1.0 - pred_probs
                        pred_probs_1 = torch.clamp(pred_probs_1, min=eps, max=1.0 - eps)

                        # 计算熵：entropy = -p * log(p) - (1-p) * log(1-p)
                        log_p = torch.log(pred_probs)
                        log_1_p = torch.log(pred_probs_1)  # 使用预先计算的1-p

                        # 使用数值稳定的熵计算
                        entropy = -pred_probs * log_p - pred_probs_1 * log_1_p

                        # 如果熵计算出现NaN，使用备用计算方式
                        if torch.isnan(entropy).any() or torch.isinf(entropy).any():
                            # 使用更安全的计算方式
                            entropy = torch.where(
                                torch.isnan(entropy) | torch.isinf(entropy),
                                torch.zeros_like(entropy),
                                entropy
                            )

                        # 计算平均熵（在所有像素上）
                        entropy_loss = entropy.mean()

                        # 如果熵损失有效，将熵约束项添加到loss中
                        if not (torch.isnan(entropy_loss).any() or torch.isinf(entropy_loss).any()):
                            loss_with_entropy = loss + args.entropy_constraint_weight * entropy_loss
                            if not (torch.isnan(loss_with_entropy).any() or torch.isinf(loss_with_entropy).any()):
                                loss = loss_with_entropy
                
                    # if ppo_agent is not None:
                            
                            
                    pbar.set_postfix(**{'loss (batch)': loss.item()})
                    if torch.isfinite(loss):
                        epoch_loss += loss.item()
                        n_finite_loss += 1
                    
                    if optimizer is not None:
                        if scaler==None:
                            loss.backward()
                            optimizer.step()
                            optimizer.zero_grad()
                        else:
                            scaler.scale(loss).backward()
                            scaler.step(optimizer)
                            scaler.update()
                            optimizer.zero_grad()
            # if ppo_agent is not None:
            #     ppo_agent.update()
            pbar.update()
            

    avg_loss = epoch_loss / max(n_finite_loss, 1)
    
    # 计算 PPO 指标的平均值
    avg_ppo_loss = sum(all_ppo_losses) / len(all_ppo_losses) if len(all_ppo_losses) > 0 else None
    avg_dist_entropy = sum(all_dist_entropies) / len(all_dist_entropies) if len(all_dist_entropies) > 0 else None
    
    # 记录epoch结束信息
    logger.info(f"=== 第 {epoch} 个epoch训练结束 ===")
    logger.info(f"平均损失: {avg_loss:.6f}")
    logger.info(f"有效batch数量: {n_finite_loss}/{len(train_loader)}")
    logger.info(f"memory_bank大小: {len(memory_bank_list)}")
    if avg_ppo_loss is not None:
        logger.info(f"平均 PPO Loss: {avg_ppo_loss:.6f}")
    if avg_dist_entropy is not None:
        logger.info(f"平均 Dist Entropy: {avg_dist_entropy:.6f}")
    
    return avg_loss, memory_bank_list, avg_ppo_loss, avg_dist_entropy




def validation_sam(args, val_loader, epoch, net: nn.Module,kmeans_target=None,kmeans_background=None,memory_bank_list_train=[],is_test=False,ppo_agent=None):
    # ppo_agent现在总是必需的，不再检查None

    net.eval()

    n_val = len(val_loader)
    # threshold = (0.1, 0.3, 0.5, 0.7, 0.9)
    threshold = [0.5]
    GPUdevice = torch.device('cuda:' + str(args.gpu_device))


        
    memory_bank_list_test = []
    memory = None
    feat_sizes = [(256, 256), (128, 128), (64, 64)]
    total_loss = 0
    total_eiou = 0
    total_dice = 0
    prompt_counts = []  # 新增：用于统计每张图生成的prompt数量
    
    # 新增：统计正负Prompt正确落在前景和背景的比例
    pos_prompt_total = 0  # 正样本prompt总数
    pos_prompt_correct = 0  # 正样本prompt正确落在前景的数量
    neg_prompt_total = 0  # 负样本prompt总数
    neg_prompt_correct = 0  # 负样本prompt正确落在背景的数量


    with tqdm(total=n_val, desc='Validation round', unit='batch', leave=False) as pbar:
        for ind, pack in enumerate(val_loader):
            
            name = pack['image_meta_dict']['filename_or_obj']
            imgs = pack['image'].to(dtype = torch.float32, device = GPUdevice)
            masks = pack['mask'].to(dtype = torch.float32, device = GPUdevice)
            raw_imgs=pack['raw_image'].to(dtype = torch.float32, device = GPUdevice)

            if 'pt' in pack:
                pt_temp = pack['pt'].to(device = GPUdevice)
                pt = pt_temp.unsqueeze(1)
                point_labels_temp = pack['p_label'].to(device = GPUdevice)
                point_labels = point_labels_temp.unsqueeze(1)
                coords_torch = torch.as_tensor(pt, dtype=torch.float, device=GPUdevice)
                labels_torch = torch.as_tensor(point_labels, dtype=torch.int, device=GPUdevice)
            else:
                coords_torch = None
                labels_torch = None



            '''test'''
            with torch.no_grad():

                """ image encoder """
                backbone_out = net.forward_image(imgs)
                _, vision_feats, vision_pos_embeds, _ = net._prepare_backbone_features(backbone_out)
                del backbone_out
                
                B = vision_feats[-1].size(1)
                
                use_memory_attention = getattr(args, 'use_memory_attention', True)
                feats = _run_memory_attention(net, vision_feats, vision_pos_embeds, memory_bank_list_train, args, B, feat_sizes, use_memory_attention)
                # 只使用PPO agent生成prompts（batch处理）
                B = feats[-1].shape[0]
                
                # 为整个batch初始化prompts和labels（每个样本一个列表）
                batch_prompts = [[] for _ in range(B)]  # List[List[[x,y]]]
                batch_labels = [[] for _ in range(B)]   # List[List[label]]
                
                # 初始化当前mask为全0（整个batch）
                current_mask = torch.zeros(B, 1, args.image_size, args.image_size, device=GPUdevice)
                current_mask_logits = torch.zeros(B, 1, args.image_size, args.image_size, device=GPUdevice)
                current_mask_logits_low_res = torch.zeros(B, 1, 256, 256, device=GPUdevice)
                
                # 固定生成Prompt数量：先生成正样本，再生成负样本
                target_prompt_num = args.positive_prompt_num  # 正样本数量
                background_prompt_num = args.negative_prompt_num  # 负样本数量
                
                # 第一阶段：为整个batch生成正样本prompts
                for i in range(target_prompt_num):
                    # 构建batch state: [B, 259, 64, 64]
                    state = feats[-1]  # [B, 256, 64, 64]
                    mask_resized = F.interpolate(current_mask, size=(state.shape[2], state.shape[3]), mode='bilinear')  # [B, 1, 64, 64]
                    
                    # 为整个batch一次性构建prompt_map
                    prompt_map = encode_prompts_to_map_gpu(
                        batch_prompts,  # List[List[[x,y]]]
                        [[l[0] for l in batch_labels[b]] for b in range(B)],  # List[List[label]]
                        state.shape[2],
                        state.shape[3],
                        sigma=1.0,
                        device=state.device,
                        batch_size=B
                    )  # [B, 2, H, W]

                    current_state = torch.cat([state, mask_resized, prompt_map], dim=1)  # [B, 259, 64, 64]

                    # 为整个batch同时生成正样本action
                    action_coords_batch = ppo_agent.select_action_pos(current_state, deterministic=True)  # [B, 2] numpy array
                    
                    # 收集新的mask和loss
                    batch_new_masks = []
                    
                    # 准备SAM推理的batch prompts
                    all_prompts_for_sam = [[] for _ in range(B)]
                    all_labels_for_sam = [[] for _ in range(B)]

                    for b in range(B):
                        y = action_coords_batch[b, 0]
                        x = action_coords_batch[b, 1]
                        label = 1  # 正样本
                        
                        batch_prompts[b].append([x, y])
                        batch_labels[b].append([label])

                        # 收集当前迭代的所有prompts和labels，用于SAM推理
                        all_prompts_for_sam[b].extend(batch_prompts[b])
                        all_labels_for_sam[b].extend([l[0] for l in batch_labels[b]])
                        
                        # 统计正样本prompt是否正确落在前景
                        # 将坐标映射到mask尺寸
                        mask_h = masks.shape[2]
                        mask_w = masks.shape[3]
                        y_int = int(y * mask_h / args.image_size)
                        x_int = int(x * mask_w / args.image_size)
                        y_int = max(0, min(y_int, mask_h - 1))
                        x_int = max(0, min(x_int, mask_w - 1))
                        
                        # 检查该位置是否在前景（mask=1）
                        if masks[b, 0, y_int, x_int] > 0.5:
                            pos_prompt_correct += 1
                        pos_prompt_total += 1

                    # 将所有prompts stack成batch tensor，一次性进行SAM推理
                    max_num_prompts = max(len(p) for p in all_prompts_for_sam)
                    padded_prompts = []
                    padded_labels = []
                    for b in range(B):
                        # Pad prompts to max_num_prompts
                        pad_prompts = all_prompts_for_sam[b] + [[0, 0]] * (max_num_prompts - len(all_prompts_for_sam[b]))
                        pad_labels = all_labels_for_sam[b] + [-1] * (max_num_prompts - len(all_labels_for_sam[b])) # -1 for padding label
                        padded_prompts.append(torch.tensor(pad_prompts, device=GPUdevice))
                        padded_labels.append(torch.tensor(pad_labels, device=GPUdevice))
                    
                    coords_torch_batch = torch.stack(padded_prompts, dim=0)  # [B, N_max, 2]
                    labels_torch_batch = torch.stack(padded_labels, dim=0)  # [B, N_max]

                    with torch.no_grad():
                        points_batch = [coords_torch_batch.float().detach(), labels_torch_batch.float().detach()]
                        # 第一次迭代不使用mask_input，从第二次开始使用前一步的mask logits
                        if i == 0:
                            mask_input_batch = None  # 第一次迭代不使用mask
                        else:
                            # 将前一步的mask logits作为mask_input传递（使用原始logit，不经过sigmoid）
                            # 直接从low_res版本使用，避免两次resize
                            mask_input_batch = current_mask_logits_low_res  # 已经是mask_input_size (256x256)
                        se, de = net.sam_prompt_encoder(
                            points=points_batch,
                            boxes=None,
                            masks=mask_input_batch,  # 第一次为None，后续使用前一步的mask logits
                            batch_size=B
                        )
                        current_high_res_feats = feats[:-1]
                        low_res_multimasks, iou_pred_batch, _, _ = net.sam_mask_decoder(
                            image_embeddings=feats[-1],
                            image_pe=net.sam_prompt_encoder.get_dense_pe(),
                            sparse_prompt_embeddings=se,
                            dense_prompt_embeddings=de,
                            multimask_output=False,
                            repeat_image=False,
                            high_res_features=current_high_res_feats
                        )
                        # 保存原始logit和iou（最后一步保存iou，避免循环后的冗余推理）
                        new_mask_logits_low_res_batch = low_res_multimasks  # [B, 1, 256, 256]，用于mask_input
                        new_mask_logits_batch = F.interpolate(low_res_multimasks, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                        new_mask_batch = (F.sigmoid(new_mask_logits_batch)).float()
                        if i == target_prompt_num - 1:
                            final_iou_predictions = iou_pred_batch.detach()
                            final_low_res_multimasks = new_mask_logits_low_res_batch.detach()
                    
                    # 更新current_mask和current_mask_logits为batch tensor（用于下一次迭代）
                    current_mask = new_mask_batch  # [B, 1, H, W]
                    current_mask_logits = new_mask_logits_batch  # [B, 1, H, W] 原始logit
                    current_mask_logits_low_res = new_mask_logits_low_res_batch  # [B, 1, 256, 256] 用于mask_input
                
                # 第二阶段：为整个batch生成负样本prompts（类似正样本的处理）
                for i in range(background_prompt_num):
                    # 构建batch state
                    state = feats[-1]
                    mask_resized = F.interpolate(current_mask, size=(state.shape[2], state.shape[3]), mode='bilinear')
                    
                    # 为整个batch一次性构建prompt_map
                    prompt_map = encode_prompts_to_map_gpu(
                        batch_prompts,  # List[List[[x,y]]]
                        [[l[0] for l in batch_labels[b]] for b in range(B)],  # List[List[label]]
                        state.shape[2],
                        state.shape[3],
                        sigma=1.0,
                        device=state.device,
                        batch_size=B
                    )  # [B, 2, H, W]

                    current_state = torch.cat([state, mask_resized, prompt_map], dim=1)  # [B, 259, 64, 64]

                    # 为整个batch同时生成负样本action
                    action_coords_batch = ppo_agent.select_action_neg(current_state, deterministic=True)

                    # 准备SAM推理的batch prompts
                    all_prompts_for_sam = [[] for _ in range(B)]
                    all_labels_for_sam = [[] for _ in range(B)]

                    for b in range(B):
                        y = action_coords_batch[b, 0]
                        x = action_coords_batch[b, 1]
                        label = 0  # 负样本
                        
                        batch_prompts[b].append([x, y])
                        batch_labels[b].append([label])

                        # 收集当前迭代的所有prompts和labels，用于SAM推理
                        all_prompts_for_sam[b].extend(batch_prompts[b])
                        all_labels_for_sam[b].extend([l[0] for l in batch_labels[b]])
                        
                        # 统计负样本prompt是否正确落在背景
                        # 将坐标映射到mask尺寸
                        mask_h = masks.shape[2]
                        mask_w = masks.shape[3]
                        y_int = int(y * mask_h / args.image_size)
                        x_int = int(x * mask_w / args.image_size)
                        y_int = max(0, min(y_int, mask_h - 1))
                        x_int = max(0, min(x_int, mask_w - 1))
                        
                        # 检查该位置是否在背景（mask=0）
                        if masks[b, 0, y_int, x_int] <= 0.5:
                            neg_prompt_correct += 1
                        neg_prompt_total += 1

                    # 将所有prompts stack成batch tensor，一次性进行SAM推理
                    max_num_prompts = max(len(p) for p in all_prompts_for_sam)
                    padded_prompts = []
                    padded_labels = []
                    for b in range(B):
                        # Pad prompts to max_num_prompts
                        pad_prompts = all_prompts_for_sam[b] + [[0, 0]] * (max_num_prompts - len(all_prompts_for_sam[b]))
                        pad_labels = all_labels_for_sam[b] + [-1] * (max_num_prompts - len(all_labels_for_sam[b])) # -1 for padding label
                        padded_prompts.append(torch.tensor(pad_prompts, device=GPUdevice))
                        padded_labels.append(torch.tensor(pad_labels, device=GPUdevice))
                    
                    coords_torch_batch = torch.stack(padded_prompts, dim=0)  # [B, N_max, 2]
                    labels_torch_batch = torch.stack(padded_labels, dim=0)  # [B, N_max]

                    with torch.no_grad():
                        points_batch = [coords_torch_batch.float().detach(), labels_torch_batch.float().detach()]
                        # 负样本循环时已经有前面的mask了，所有迭代都使用mask_input
                        # 将前一步的mask logits作为mask_input传递（使用原始logit，不经过sigmoid）
                        # 直接从low_res版本使用，避免两次resize
                        mask_input_batch = current_mask_logits_low_res  # 已经是mask_input_size (256x256)
                        se, de = net.sam_prompt_encoder(
                            points=points_batch,
                            boxes=None,
                            masks=mask_input_batch,  # 使用前一步的mask logits作为mask prompt
                            batch_size=B
                        )
                        current_high_res_feats = feats[:-1]
                        low_res_multimasks, iou_pred_batch, _, _ = net.sam_mask_decoder(
                            image_embeddings=feats[-1],
                            image_pe=net.sam_prompt_encoder.get_dense_pe(),
                            sparse_prompt_embeddings=se,
                            dense_prompt_embeddings=de,
                            multimask_output=False,
                            repeat_image=False,
                            high_res_features=current_high_res_feats
                        )
                        # 保存原始logit和iou（最后一步保存iou，避免循环后的冗余推理）
                        new_mask_logits_low_res_batch = low_res_multimasks  # [B, 1, 256, 256]，用于mask_input
                        new_mask_logits_batch = F.interpolate(low_res_multimasks, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                        new_mask_batch = (F.sigmoid(new_mask_logits_batch)).float()
                        if i == background_prompt_num - 1:
                            final_iou_predictions = iou_pred_batch.detach()
                            final_low_res_multimasks = new_mask_logits_low_res_batch.detach()
                    
                    # 更新current_mask和current_mask_logits为batch tensor（用于下一次迭代）
                    current_mask = new_mask_batch  # [B, 1, H, W]
                    current_mask_logits = new_mask_logits_batch  # [B, 1, H, W] 原始logit
                    current_mask_logits_low_res = new_mask_logits_low_res_batch  # [B, 1, 256, 256] 用于mask_input
                
                # 统计prompt数量并转换为tensor
                all_coords = []
                all_labels = []
                for b in range(B):
                    prompt_counts.append(len(batch_prompts[b]))
                    prompts_tensor = torch.tensor(batch_prompts[b], device=GPUdevice).unsqueeze(0)  # [1, N, 2]
                    labels_tensor = torch.tensor([l[0] for l in batch_labels[b]], device=GPUdevice).unsqueeze(0)  # [1, N]
                    all_coords.append(prompts_tensor)
                    all_labels.append(labels_tensor)

                    # ppo_agent.update()
                    # coords_torch = torch.cat(all_coords, dim=0)
                    # labels_torch = torch.cat(all_labels, dim=0)
                                        
                image_embed = feats[-1]
                high_res_feats = feats[:-1]

                preds=[]
                high_res_preds=[]
                iou_predictions=[]
                for b in range(feats[-1].shape[0]):
                    pred_b = F.interpolate(final_low_res_multimasks[b:b+1], size=(args.out_size, args.out_size), mode="bilinear", align_corners=False)
                    high_res_multimasks_b = F.interpolate(final_low_res_multimasks[b:b+1], size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                    preds.append(pred_b)
                    high_res_preds.append(high_res_multimasks_b)
                    iou_predictions.append(final_iou_predictions[b:b+1])
                '''memory encoder'''       
                # new caluculated memory features
                high_res_multimasks=torch.cat(high_res_preds,dim=0)
                pred=torch.cat(preds,dim=0)
                iou_predictions=torch.cat(iou_predictions,dim=0)

                # 使用 SAM2 的后处理（使用 SAM2 原始默认参数）
                from sam2_train.utils.transforms import SAM2Transforms
                sam2_transforms = SAM2Transforms(
                    resolution=args.image_size,
                    mask_threshold=0.0,
                    max_hole_area=200.0,
                    max_sprinkle_area=200.0
                )
                pred = sam2_transforms.postprocess_masks(
                    pred,
                    orig_hw=(args.out_size, args.out_size)
                )
                # 应用 sigmoid 和阈值（使用 0.5 作为二值化阈值）
                pred = (torch.sigmoid(pred) > 0.5).float()
                # 确保pred在[0, 1]范围内
                pred = torch.clamp(pred, 0.0, 1.0)
                # 确保pred和masks的形状匹配
                if pred.shape != masks.shape:
                    if pred.shape[2:] != masks.shape[2:]:
                        pred = F.interpolate(pred, size=masks.shape[2:], mode='bilinear', align_corners=False)
                        pred = (pred > 0.5).float()
                
                if is_test:
                    raw_imgs=raw_imgs.detach()
                    raw_imgs = F.interpolate(raw_imgs,(1024,1024)).permute(0,2,3,1)
                    pred_save = raw_imgs.cpu().numpy()

                    for i in range(pred_save.shape[0]):
                        mask_save = pred_save[i]*255
                        # mask_save = np.transpose(mask_save,(1,2,0))
                        if coords_torch is not None:
                            coords=coords_torch[i].detach().cpu().numpy()
                            for j in range(3):
                                mark_area(mask_save,coords[j,0],coords[j,1],[255,0,0])
                                mark_area(mask_save,coords[j+3,0],coords[j+3,1],[0,0,255])
                                # mask_save[coords[j,0],coords[j,1],:]=[255,0,0]
                                # mask_save[coords[j+3,0],coords[j+3,1],:]=[0,0,255]
                        mask_save = Image.fromarray(np.uint8(mask_save))
                        name_save=name[i]
                        mask_save.save(os.path.join('./test_save/',name_save))
                        
                temp = eval_seg(pred, masks, threshold)
                total_eiou += temp[0]
                total_dice += temp[1]
                
                ppo_agent.reset_buffer()

                '''vis images'''
                # if ind % args.vis == 0:
                #     namecat = 'Test'
                #     for na in name:
                #         img_name = na
                #         namecat = namecat + img_name + '+'
                #     vis_image(imgs,pred, masks, os.path.join(args.path_helper['sample_path'], namecat+'epoch+' +str(epoch) + '.jpg'), reverse=False, points=None)
                            
            pbar.update()

    # if len(prompt_counts) > 0:
    #     avg_prompt_num = sum(prompt_counts) / len(prompt_counts)
    #     max_prompt_num = max(prompt_counts)
    #     min_prompt_num = min(prompt_counts)
    #     print(f"[Val Epoch {epoch}] 平均每张图生成Prompt数量: {avg_prompt_num:.2f}，最大: {max_prompt_num}，最小: {min_prompt_num}")
    
    # 输出正负Prompt正确落在前景和背景的统计结果
    pos_accuracy = None
    neg_accuracy = None
    if pos_prompt_total > 0:
        pos_accuracy = pos_prompt_correct / pos_prompt_total * 100
        print(f"[Val Epoch {epoch}] 正样本Prompt统计: {pos_prompt_correct}/{pos_prompt_total} ({pos_accuracy:.2f}%) 正确落在前景")
    if neg_prompt_total > 0:
        neg_accuracy = neg_prompt_correct / neg_prompt_total * 100
        print(f"[Val Epoch {epoch}] 负样本Prompt统计: {neg_prompt_correct}/{neg_prompt_total} ({neg_accuracy:.2f}%) 正确落在背景")
    
    return  tuple([total_eiou/n_val, total_dice/n_val, pos_accuracy, neg_accuracy])

def test_sam(args, val_loader, epoch, net: nn.Module,target_centroids=None,background_centroids=None,memory_bank_list_train =[],is_save=False,ppo_agent=None,is_show=False):
    # ppo_agent现在总是必需的，不再检查None


    # eval mode
    net.eval()

    n_val = len(val_loader)
    # threshold = (0.1, 0.3, 0.5, 0.7, 0.9)
    threshold = [0.5]
    GPUdevice = torch.device('cuda:' + str(args.gpu_device))

    # init
    # lossfunc = criterion_G
    
    # try:
    #     with open(args.memory_path, 'rb') as f:
    #         memory_bank_list_train = pickle.load(f)
    # except:
    #     print('No exist memory.pkl')
    #     memory_bank_list_train = []
        
    memory_bank_list_test = []
    memory = None
    feat_sizes = [(256, 256), (128, 128), (64, 64)]
    total_loss = 0
    total_eiou = 0
    total_dice = 0
    prompt_counts = []  # 新增：用于统计每张图生成的prompt数量
    pos_prompt_total = 0  # 正样本prompt总数
    pos_prompt_correct = 0  # 正样本prompt正确落在前景的数量
    neg_prompt_total = 0  # 负样本prompt总数
    neg_prompt_correct = 0  # 负样本prompt正确落在背景的数量


    with tqdm(total=n_val, desc='Validation round', unit='batch', leave=False) as pbar:
        for ind, pack in enumerate(val_loader):
            name = pack['image_meta_dict']['filename_or_obj']
            imgs = pack['image'].to(dtype = torch.float32, device = GPUdevice)
            masks = pack['mask'].to(dtype = torch.float32, device = GPUdevice)
            raw_imgs=pack['raw_image'].to(dtype = torch.float32, device = GPUdevice)

            
            if 'pt' in pack:
                pt_temp = pack['pt'].to(device = GPUdevice)
                pt = pt_temp.unsqueeze(1)
                point_labels_temp = pack['p_label'].to(device = GPUdevice)
                point_labels = point_labels_temp.unsqueeze(1)
                coords_torch = torch.as_tensor(pt, dtype=torch.float, device=GPUdevice)
                labels_torch = torch.as_tensor(point_labels, dtype=torch.int, device=GPUdevice)
            else:
                coords_torch = None
                labels_torch = None



            '''test'''
            with torch.no_grad():

                """ image encoder """
                backbone_out = net.forward_image(imgs)
                _, vision_feats, vision_pos_embeds, _ = net._prepare_backbone_features(backbone_out)
                del backbone_out
                
                B = vision_feats[-1].size(1)
                
                use_memory_attention = getattr(args, 'use_memory_attention', True)
                feats = _run_memory_attention(net, vision_feats, vision_pos_embeds, memory_bank_list_train, args, B, feat_sizes, use_memory_attention)
                # 只使用PPO agent生成prompts（batch处理）
                B = feats[-1].shape[0]

                # 为整个batch初始化prompts和labels（每个样本一个列表）
                batch_prompts = [[] for _ in range(B)]  # List[List[[x,y]]]
                batch_labels = [[] for _ in range(B)]   # List[List[label]]

                # 初始化当前mask为全0（整个batch）
                current_mask = torch.zeros(B, 1, args.image_size, args.image_size, device=GPUdevice)
                current_mask_logits = torch.zeros(B, 1, args.image_size, args.image_size, device=GPUdevice)
                current_mask_logits_low_res = torch.zeros(B, 1, 256, 256, device=GPUdevice)

                # 固定生成Prompt数量：先生成正样本，再生成负样本
                target_prompt_num = args.positive_prompt_num  # 正样本数量
                background_prompt_num = args.negative_prompt_num  # 负样本数量

                # 第一阶段：为整个batch生成正样本prompts
                for i in range(target_prompt_num):
                    # 构建batch state: [B, 261, 64, 64]
                    state = feats[-1]  # [B, 256, 64, 64]
                    mask_resized = F.interpolate(current_mask, size=(state.shape[2], state.shape[3]), mode='bilinear')  # [B, 1, 64, 64]

                    # 为整个batch一次性构建prompt_map
                    prompt_map = encode_prompts_to_map_gpu(
                        batch_prompts,  # List[List[[x,y]]]
                        [[l[0] for l in batch_labels[b]] for b in range(B)],  # List[List[label]]
                        state.shape[2],
                        state.shape[3],
                        sigma=1.0,
                        device=state.device,
                        batch_size=B
                    )  # [B, 2, H, W]

                    current_state = torch.cat([state, mask_resized, prompt_map], dim=1)  # [B, 259, 64, 64]

                    # 为整个batch同时生成正样本action
                    action_coords_batch = ppo_agent.select_action_pos(current_state, deterministic=True)  # [B, 2] numpy array
                    
                    # 准备SAM推理的batch prompts
                    all_prompts_for_sam = [[] for _ in range(B)]
                    all_labels_for_sam = [[] for _ in range(B)]

                    for b in range(B):
                        y = action_coords_batch[b, 0]
                        x = action_coords_batch[b, 1]
                        label = 1  # 正样本
                        
                        batch_prompts[b].append([x, y])
                        batch_labels[b].append([label])

                        # 收集当前迭代的所有prompts和labels，用于SAM推理
                        all_prompts_for_sam[b].extend(batch_prompts[b])
                        all_labels_for_sam[b].extend([l[0] for l in batch_labels[b]])
                        
                        # 统计正样本prompt是否正确落在前景
                        # 将坐标映射到mask尺寸
                        mask_h = masks.shape[2]
                        mask_w = masks.shape[3]
                        y_int = int(y * mask_h / args.image_size)
                        x_int = int(x * mask_w / args.image_size)
                        y_int = max(0, min(y_int, mask_h - 1))
                        x_int = max(0, min(x_int, mask_w - 1))
                        
                        # 检查该位置是否在前景（mask=1）
                        if masks[b, 0, y_int, x_int] > 0.5:
                            pos_prompt_correct += 1
                        pos_prompt_total += 1

                    # 将所有prompts stack成batch tensor，一次性进行SAM推理
                    max_num_prompts = max(len(p) for p in all_prompts_for_sam)
                    padded_prompts = []
                    padded_labels = []
                    for b in range(B):
                        # Pad prompts to max_num_prompts
                        pad_prompts = all_prompts_for_sam[b] + [[0, 0]] * (max_num_prompts - len(all_prompts_for_sam[b]))
                        pad_labels = all_labels_for_sam[b] + [-1] * (max_num_prompts - len(all_labels_for_sam[b])) # -1 for padding label
                        padded_prompts.append(torch.tensor(pad_prompts, device=GPUdevice))
                        padded_labels.append(torch.tensor(pad_labels, device=GPUdevice))
                    
                    coords_torch_batch = torch.stack(padded_prompts, dim=0)  # [B, N_max, 2]
                    labels_torch_batch = torch.stack(padded_labels, dim=0)  # [B, N_max]

                    with torch.no_grad():
                        points_batch = [coords_torch_batch.float().detach(), labels_torch_batch.float().detach()]
                        # 第一次迭代不使用mask_input，从第二次开始使用前一步的mask logits
                        if i == 0:
                            mask_input_batch = None  # 第一次迭代不使用mask
                        else:
                            # 将前一步的mask logits作为mask_input传递（使用原始logit，不经过sigmoid）
                            # 直接从low_res版本使用，避免两次resize
                            mask_input_batch = current_mask_logits_low_res  # 已经是mask_input_size (256x256)
                        se, de = net.sam_prompt_encoder(
                            points=points_batch,
                            boxes=None,
                            masks=mask_input_batch,  # 第一次为None，后续使用前一步的mask logits
                            batch_size=B
                        )
                        current_high_res_feats = feats[:-1]
                        low_res_multimasks, iou_pred_batch, _, _ = net.sam_mask_decoder(
                            image_embeddings=feats[-1],
                            image_pe=net.sam_prompt_encoder.get_dense_pe(),
                            sparse_prompt_embeddings=se,
                            dense_prompt_embeddings=de,
                            multimask_output=False,
                            repeat_image=False,
                            high_res_features=current_high_res_feats
                        )
                        # 保存原始logit和iou（最后一步保存iou，避免循环后的冗余推理）
                        new_mask_logits_low_res_batch = low_res_multimasks  # [B, 1, 256, 256]，用于mask_input
                        new_mask_logits_batch = F.interpolate(low_res_multimasks, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                        new_mask_batch = (F.sigmoid(new_mask_logits_batch)).float()
                        if i == target_prompt_num - 1:
                            final_iou_predictions = iou_pred_batch.detach()
                            final_low_res_multimasks = new_mask_logits_low_res_batch.detach()
                    
                    # 更新current_mask和current_mask_logits为batch tensor（用于下一次迭代）
                    current_mask = new_mask_batch  # [B, 1, H, W]
                    current_mask_logits = new_mask_logits_batch  # [B, 1, H, W] 原始logit
                    current_mask_logits_low_res = new_mask_logits_low_res_batch  # [B, 1, 256, 256] 用于mask_input
                
                # 第二阶段：为整个batch生成负样本prompts（类似正样本的处理）
                for i in range(background_prompt_num):
                    # 构建batch state
                    state = feats[-1]
                    mask_resized = F.interpolate(current_mask, size=(state.shape[2], state.shape[3]), mode='bilinear')

                    # 为整个batch一次性构建prompt_map
                    prompt_map = encode_prompts_to_map_gpu(
                        batch_prompts,  # List[List[[x,y]]]
                        [[l[0] for l in batch_labels[b]] for b in range(B)],  # List[List[label]]
                        state.shape[2],
                        state.shape[3],
                        sigma=1.0,
                        device=state.device,
                        batch_size=B
                    )  # [B, 2, H, W]

                    current_state = torch.cat([state, mask_resized, prompt_map], dim=1)  # [B, 259, 64, 64]

                    # 为整个batch同时生成负样本action
                    action_coords_batch = ppo_agent.select_action_neg(current_state, deterministic=True)

                    # 准备SAM推理的batch prompts
                    all_prompts_for_sam = [[] for _ in range(B)]
                    all_labels_for_sam = [[] for _ in range(B)]

                    for b in range(B):
                        y = action_coords_batch[b, 0]
                        x = action_coords_batch[b, 1]
                        label = 0  # 负样本
                        
                        batch_prompts[b].append([x, y])
                        batch_labels[b].append([label])

                        # 收集当前迭代的所有prompts和labels，用于SAM推理
                        all_prompts_for_sam[b].extend(batch_prompts[b])
                        all_labels_for_sam[b].extend([l[0] for l in batch_labels[b]])
                        
                        # 统计负样本prompt是否正确落在背景
                        # 将坐标映射到mask尺寸
                        mask_h = masks.shape[2]
                        mask_w = masks.shape[3]
                        y_int = int(y * mask_h / args.image_size)
                        x_int = int(x * mask_w / args.image_size)
                        y_int = max(0, min(y_int, mask_h - 1))
                        x_int = max(0, min(x_int, mask_w - 1))
                        
                        # 检查该位置是否在背景（mask<0.5）
                        if masks[b, 0, y_int, x_int] <= 0.5:
                            neg_prompt_correct += 1
                        neg_prompt_total += 1

                    # 将所有prompts stack成batch tensor，一次性进行SAM推理
                    max_num_prompts = max(len(p) for p in all_prompts_for_sam)
                    padded_prompts = []
                    padded_labels = []
                    for b in range(B):
                        # Pad prompts to max_num_prompts
                        pad_prompts = all_prompts_for_sam[b] + [[0, 0]] * (max_num_prompts - len(all_prompts_for_sam[b]))
                        pad_labels = all_labels_for_sam[b] + [-1] * (max_num_prompts - len(all_labels_for_sam[b])) # -1 for padding label
                        padded_prompts.append(torch.tensor(pad_prompts, device=GPUdevice))
                        padded_labels.append(torch.tensor(pad_labels, device=GPUdevice))
                    
                    coords_torch_batch = torch.stack(padded_prompts, dim=0)  # [B, N_max, 2]
                    labels_torch_batch = torch.stack(padded_labels, dim=0)  # [B, N_max]

                    with torch.no_grad():
                        points_batch = [coords_torch_batch.float().detach(), labels_torch_batch.float().detach()]
                        # 负样本循环时已经有前面的mask了，所有迭代都使用mask_input
                        # 将前一步的mask logits作为mask_input传递（使用原始logit，不经过sigmoid）
                        # 直接从low_res版本使用，避免两次resize
                        mask_input_batch = current_mask_logits_low_res  # 已经是mask_input_size (256x256)
                        se, de = net.sam_prompt_encoder(
                            points=points_batch,
                            boxes=None,
                            masks=mask_input_batch,  # 使用前一步的mask logits作为mask prompt
                            batch_size=B
                        )
                        current_high_res_feats = feats[:-1]
                        low_res_multimasks, iou_pred_batch, _, _ = net.sam_mask_decoder(
                            image_embeddings=feats[-1],
                            image_pe=net.sam_prompt_encoder.get_dense_pe(),
                            sparse_prompt_embeddings=se,
                            dense_prompt_embeddings=de,
                            multimask_output=False,
                            repeat_image=False,
                            high_res_features=current_high_res_feats
                        )
                        # 保存原始logit和iou（最后一步保存iou，避免循环后的冗余推理）
                        new_mask_logits_low_res_batch = low_res_multimasks  # [B, 1, 256, 256]，用于mask_input
                        new_mask_logits_batch = F.interpolate(low_res_multimasks, size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                        new_mask_batch = (F.sigmoid(new_mask_logits_batch)).float()
                        if i == background_prompt_num - 1:
                            final_iou_predictions = iou_pred_batch.detach()
                            final_low_res_multimasks = new_mask_logits_low_res_batch.detach()
                    
                    # 更新current_mask和current_mask_logits为batch tensor（用于下一次迭代）
                    current_mask = new_mask_batch  # [B, 1, H, W]
                    current_mask_logits = new_mask_logits_batch  # [B, 1, H, W] 原始logit
                    current_mask_logits_low_res = new_mask_logits_low_res_batch  # [B, 1, 256, 256] 用于mask_input
                
                # 统计prompt数量并转换为tensor
                all_coords = []
                all_labels = []
                for b in range(B):
                    prompt_counts.append(len(batch_prompts[b]))
                    prompts_tensor = torch.tensor(batch_prompts[b], device=GPUdevice).unsqueeze(0)  # [1, N, 2]
                    labels_tensor = torch.tensor([l[0] for l in batch_labels[b]], device=GPUdevice).unsqueeze(0)  # [1, N]
                    all_coords.append(prompts_tensor)
                    all_labels.append(labels_tensor)

                    # ppo_agent.update()
                    # coords_torch = torch.cat(all_coords, dim=0)
                    # labels_torch = torch.cat(all_labels, dim=0)
                                        
                image_embed = feats[-1]
                high_res_feats = feats[:-1]

                preds=[]
                high_res_preds=[]
                iou_predictions=[]
                for b in range(feats[-1].shape[0]):
                    pred_b = F.interpolate(final_low_res_multimasks[b:b+1], size=(args.out_size, args.out_size), mode="bilinear", align_corners=False)
                    high_res_multimasks_b = F.interpolate(final_low_res_multimasks[b:b+1], size=(args.image_size, args.image_size), mode="bilinear", align_corners=False)
                    preds.append(pred_b)
                    high_res_preds.append(high_res_multimasks_b)
                    iou_predictions.append(final_iou_predictions[b:b+1])
                '''memory encoder'''       
                # new caluculated memory features
                high_res_multimasks=torch.cat(high_res_preds,dim=0)
                pred=torch.cat(preds,dim=0)
                iou_predictions=torch.cat(iou_predictions,dim=0)

                # Step 1: SAM2Transforms 后处理（对齐官方：在 low_res logits 空间操作，内部含 resize）
                # 注意：pred 现在是 (B,C,256,256) 低分辨率，连通域参数需按比例调整
                # 原 1024² 参数 / 16 ≈ 256² 对应参数
                from sam2_train.utils.transforms import SAM2Transforms
                sam2_transforms = SAM2Transforms(
                    resolution=args.image_size,
                    mask_threshold=0.0,
                    max_hole_area=200.0,
                    max_sprinkle_area=200.0
                )
                pred = sam2_transforms.postprocess_masks(
                    pred,
                    orig_hw=(args.out_size, args.out_size)
                )

                # Step 2: Sigmoid + 二值化（阈值=0.5）→ 此时为 Raw 结果
                pred_raw = (torch.sigmoid(pred) > 0.5).float()

                if args.use_extra_postprocess:
                    from func_2d.postprocess import postprocess_segmentation_mask
                    pred_post = postprocess_segmentation_mask(
                        pred_raw.detach().cpu().numpy(),
                        min_area_ratio=args.postprocess_min_area_ratio,
                        morph_kernel_size=args.postprocess_morph_kernel_size,
                        use_largest_component=args.postprocess_keep_largest_only
                    )
                    pred = torch.tensor((pred_post / 255.0).astype(np.float32), device=pred_raw.device).unsqueeze(1)
                    if is_save:
                        pred_save = pred_post
                        for i in range(pred_save.shape[0]):
                            mask_save = pred_save[i]
                            if mask_save.ndim == 2:
                                mask_save = mask_save[:, :, np.newaxis]
                            mask_save = np.repeat(mask_save, 3, axis=-1)
                            mask_save = Image.fromarray(np.uint8(mask_save))
                            name_save = name[i].replace('.jpg', '.png')
                            mask_save.save(os.path.join(args.test_save_path, name_save))
                else:
                    pred = pred_raw
                    if is_save:
                        pred_save_np = (pred_raw.detach().cpu().numpy() * 255).astype(np.uint8)
                        for i in range(pred_save_np.shape[0]):
                            mask_save = pred_save_np[i, 0] if pred_save_np.ndim == 4 else pred_save_np[i]
                            if mask_save.ndim == 2:
                                mask_save = mask_save[:, :, np.newaxis]
                            mask_save = np.repeat(mask_save, 3, axis=-1)
                            mask_save = Image.fromarray(mask_save)
                            name_save = name[i].replace('.jpg', '.png')
                            mask_save.save(os.path.join(args.test_save_path, name_save))
                        
                # 确保pred在[0, 1]范围内（双重保险）
                pred = torch.clamp(pred, 0.0, 1.0)
                # 确保pred和masks的形状匹配
                if pred.shape != masks.shape:
                    # 如果形状不匹配，尝试调整pred的形状
                    if pred.shape[2:] != masks.shape[2:]:
                        pred = F.interpolate(pred, size=masks.shape[2:], mode='bilinear', align_corners=False)
                        pred = (pred > 0.5).float()
                temp = eval_seg(pred, masks, threshold)
                total_eiou += temp[0]
                total_dice += temp[1]
                if is_show:
                    raw_imgs = raw_imgs.detach()
                    raw_imgs = F.interpolate(raw_imgs, (1024, 1024)).permute(0, 2, 3, 1)
                    pred_save = raw_imgs.cpu().numpy()

                    for i in range(pred_save.shape[0]):
                        mask_save = pred_save[i] * 255
                        mask_save = mask_save.astype(np.uint8)
                        if all_coords:
                            coords = all_coords[i].detach().cpu().numpy()  # (1, N, 2)
                            labels = all_labels[i].detach().cpu().numpy()  # (1, N)
                            coords = coords[0]
                            labels = labels[0]
                            
                            # print(f"Image {i}: {coords.shape[0]} points")  # 调试用
                            
                            for j in range(coords.shape[0]):
                                x, y = int(coords[j, 0]), int(coords[j, 1])
                                if labels[j] == 1:
                                    mark_area(mask_save, x, y, [255, 0, 0], radius=12, shape='circle')
                                else:
                                    mark_area(mask_save, x, y, [0, 0, 255], radius=12, shape='circle')
                        mask_save = Image.fromarray(mask_save)
                        name_save = name[i].replace('.jpg','.png')
                        mask_save.save(os.path.join(args.test_save_path, name_save))
                ppo_agent.reset_buffer()
                          
            pbar.update()

    # if len(prompt_counts) > 0:
    #     avg_prompt_num = sum(prompt_counts) / len(prompt_counts)
    #     max_prompt_num = max(prompt_counts)
    #     min_prompt_num = min(prompt_counts)
    #     print(f"[Test Epoch {epoch}] 平均每张图生成Prompt数量: {avg_prompt_num:.2f}，最大: {max_prompt_num}，最小: {min_prompt_num}")
    
    # 输出正负Prompt正确落在前景和背景的统计结果
    pos_accuracy = None
    neg_accuracy = None
    if pos_prompt_total > 0:
        pos_accuracy = pos_prompt_correct / pos_prompt_total * 100
        print(f"[Test Epoch {epoch}] 正样本Prompt统计: {pos_prompt_correct}/{pos_prompt_total} ({pos_accuracy:.2f}%) 正确落在前景")
    if neg_prompt_total > 0:
        neg_accuracy = neg_prompt_correct / neg_prompt_total * 100
        print(f"[Test Epoch {epoch}] 负样本Prompt统计: {neg_prompt_correct}/{neg_prompt_total} ({neg_accuracy:.2f}%) 正确落在背景")
    
    return  tuple([total_eiou/n_val, total_dice/n_val, pos_accuracy, neg_accuracy])

# 特征提取功能已移至 func_2d/feature_extraction.py
# 如需使用示例，请运行: python func_2d/feature_extraction.py
